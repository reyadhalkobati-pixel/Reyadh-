import React from "react";

export default function Home() {
  const activities = [
    { name: "Upload", link: "/upload" },
    { name: "Create New", link: "/create" },
    { name: "Search", link: "/search" },
    { name: "Settings", link: "/settings" },
    { name: "Profile", link: "/profile" }
  ];

  const files = [
    "Report Q1 2025.xlsx",
    "Design Specification.pdf",
    "Budget Overview.xlsx",
    "Meeting Notes.docx",
    "Presentation.pptx",
    "Project Plan.docx"
  ];

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 font-sans">
      {/* Header */}
      <header className="bg-[#1E3A8A] text-white">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between">
          <h1 className="text-xl font-semibold">My App</h1>
          <nav className="mt-2 sm:mt-0">
            {activities.map((act) => (
              <a
                key={act.name}
                href={act.link}
                className="inline-block px-3 py-1 rounded-md hover:bg-[#1E3A8A]/70 transition-colors"
              >
                {act.name}
              </a>
            ))}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* File List Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-medium mb-4">Current Files</h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.map((file) => (
              <li
                key={file}
                className="bg-white rounded-lg shadow-sm p-4 flex flex-col justify-between hover:shadow-md transition-shadow"
              >
                <span className="font-medium text-gray-700">{file}</span>
                <div className="mt-4 flex justify-end space-x-2">
                  <button
                    className="text-sm text-[#1E3A8A] hover:text-[#1E3A8A]/80"
                  >
                    Download
                  </button>
                  <button
                    className="text-sm text-[#1E3A8A] hover:text-[#1E3A8A]/80"
                  >
                    Delete
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </section>

        {/* Activities Overview */}
        <section>
          <h2 className="text-2xl font-medium mb-4">All Activities</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {activities.map((act) => (
              <a
                key={act.name}
                href={act.link}
                className="block bg-white rounded-lg shadow-sm p-6 h-32 flex flex-col justify-between hover:shadow-md transition-shadow"
              >
                <span className="text-lg font-medium text-gray-900">{act.name}</span>
                <span className="text-sm text-gray-600">
                  Quick access to {act.name.toLowerCase()} features
                </span>
              </a>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-[#1E3A8A] text-white py-4">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm">
          © 2026 My App – All rights reserved.
        </div>
      </footer>
    </div>
  );
}