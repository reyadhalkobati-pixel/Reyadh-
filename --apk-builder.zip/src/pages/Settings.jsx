import React from "react";

export default function SettingsPage() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 font-inter">
      <header className="bg-[#1E3A8A] text-white py-6 shadow-md">
        <h1 className="text-3xl font-semibold text-center">
          Settings
        </h1>
      </header>

      <main className="max-w-5xl mx-auto py-8 px-4 sm:px-6 lg:px-8 space-y-12">
        {/* General Settings */}
        <section className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-xl font-medium mb-4 text-[#1E3A8A]">
            General Settings
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-1 font-semibold">
                Theme
              </label>
              <select className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700">
                <option>Light</option>
                <option>Dark</option>
                <option>Auto</option>
              </select>
            </div>
            <div>
              <label className="block text-sm mb-1 font-semibold">
                Language
              </label>
              <select className="w-full p-2 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700">
                <option>English</option>
                <option>Español</option>
                <option>Français</option>
              </select>
            </div>
          </div>
        </section>

        {/* Temporary Files */}
        <section className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-xl font-medium mb-4 text-[#1E3A8A]">
            Temporary Files
          </h2>
          <p className="mb-4">
            Current cache size: <strong>42 MB</strong>. Clearing temporarily
            cached data will free up space.
          </p>
          <button className="px-4 py-2 rounded bg-[#1E3A8A] text-white hover:bg-[#0C2D6F] transition-colors">
            Clear Cache
          </button>
        </section>

        {/* Notification Settings */}
        <section className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-xl font-medium mb-4 text-[#1E3A8A]">
            Notification Settings
          </h2>
          <div className="space-y-4">
            <label className="flex items-center space-x-3">
              <input type="checkbox" defaultChecked className="h-5 w-5 text-[#1E3A8A]" />
              <span>Show Email Alerts</span>
            </label>
            <label className="flex items-center space-x-3">
              <input type="checkbox" className="h-5 w-5 text-[#1E3A8A]" />
              <span>Show SMS Alerts</span>
            </label>
            <label className="flex items-center space-x-3">
              <input type="checkbox" defaultChecked className="h-5 w-5 text-[#1E3A8A]" />
              <span>Show Push Notifications</span>
            </label>
          </div>
        </section>

        {/* External Integrations */}
        <section className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
          <h2 className="text-xl font-medium mb-4 text-[#1E3A8A]">
            External Integrations
          </h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Google Calendar</span>
              <select className="p-2 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700">
                <option>Connected</option>
                <option>Not Connected</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <span>Slack</span>
              <select className="p-2 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700">
                <option>Connected</option>
                <option>Not Connected</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <span>Zapier</span>
              <select className="p-2 rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700">
                <option>Connected</option>
                <option>Not Connected</option>
              </select>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}