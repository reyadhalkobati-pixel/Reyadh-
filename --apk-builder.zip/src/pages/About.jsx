export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#1E3A8A] text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold font-sans">About QAbout</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-[#1E3A8A] mb-4">Application Overview</h2>
          <p className="text-gray-700 leading-relaxed">
            QAbout is a comprehensive application designed to provide users with detailed information about various topics. Our platform offers a user-friendly interface and a wealth of resources to help you find the information you need quickly and efficiently.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold text-[#1E3A8A] mb-4">Version Information</h2>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-[#1E3A8A] mb-2">Current Version</h3>
            <p className="text-gray-700">1.2.0</p>
            <p className="text-gray-500 text-sm mt-2">Released on October 15, 2023</p>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-bold text-[#1E3A8A] mb-4">Application Architecture</h2>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-[#1E3A8A] mb-2">Frontend</h3>
            <p className="text-gray-700 mb-4">
              Our frontend is built using React with TypeScript, providing a responsive and dynamic user experience. We utilize Tailwind CSS for styling to ensure a consistent and modern look across all devices.
            </p>

            <h3 className="text-xl font-semibold text-[#1E3A8A] mb-2">Backend</h3>
            <p className="text-gray-700 mb-4">
              The backend is powered by Node.js with Express, offering a robust and scalable server-side solution. We use MongoDB as our database to store and manage all application data efficiently.
            </p>

            <h3 className="text-xl font-semibold text-[#1E3A8A] mb-2">API</h3>
            <p className="text-gray-700">
              Our RESTful API follows best practices for security and performance, ensuring seamless communication between the frontend and backend components of the application.
            </p>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-bold text-[#1E3A8A] mb-4">Support</h2>
          <p className="text-gray-700 mb-4">
            We're here to help! If you have any questions, encounter issues, or need assistance, please don't hesitate to reach out to our support team.
          </p>
          <a
            href="mailto:support@qabout.com"
            className="inline-block bg-[#1E3A8A] text-white px-6 py-2 rounded-lg hover:bg-blue-900 transition-colors duration-300"
          >
            Contact Support
          </a>
        </section>
      </main>

      <footer className="bg-[#1E3A8A] text-white py-6 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; {new Date().getFullYear()} QAbout. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}