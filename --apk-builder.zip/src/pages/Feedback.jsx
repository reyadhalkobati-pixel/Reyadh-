export default function FeedbackPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-[#1E3A8A] text-white py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold font-inter">Feedback</h1>
          <p className="mt-2">Help us improve your smart organization experience</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <h2 className="text-2xl font-bold text-[#1E3A8A] mb-6">We Value Your Feedback</h2>

            <form className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent"
                  placeholder="Your name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent"
                  placeholder="Your email"
                />
              </div>

              <div>
                <label htmlFor="feedback-type" className="block text-sm font-medium text-gray-700 mb-1">Feedback Type</label>
                <select
                  id="feedback-type"
                  name="feedback-type"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent"
                >
                  <option value="">Select a type</option>
                  <option value="bug">Bug Report</option>
                  <option value="feature">Feature Request</option>
                  <option value="improvement">Improvement Suggestion</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label htmlFor="feedback" className="block text-sm font-medium text-gray-700 mb-1">Your Feedback</label>
                <textarea
                  id="feedback"
                  name="feedback"
                  rows="5"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent"
                  placeholder="Please share your thoughts and suggestions..."
                ></textarea>
              </div>

              <div className="flex items-center">
                <input
                  id="subscribe"
                  name="subscribe"
                  type="checkbox"
                  className="h-4 w-4 text-[#1E3A8A] focus:ring-[#1E3A8A] border-gray-300 rounded"
                />
                <label htmlFor="subscribe" className="ml-2 block text-sm text-gray-700">
                  Subscribe to updates about your feedback
                </label>
              </div>

              <div>
                <button
                  type="submit"
                  className="w-full bg-[#1E3A8A] hover:bg-[#152A63] text-white font-medium py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1E3A8A]"
                >
                  Submit Feedback
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>

      <footer className="bg-gray-100 py-6 mt-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2023 Smart Organization. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}