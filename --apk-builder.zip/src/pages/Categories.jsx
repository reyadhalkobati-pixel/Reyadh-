```jsx
export default function CategoriesPage() {
  const [categories, setCategories] = React.useState([
    { id: 1, name: "Documents", color: "#F59E0B" },
    { id: 2, name: "Images", color: "#10B981" },
    { id: 3, name: "Videos", color: "#EF4444" },
  ]);

  const [newTag, setNewTag] = React.useState("");
  const [searchTerm, setSearchTerm] = React.useState("");

  const handleAdd = () => {
    if (!newTag.trim()) return;
    setCategories(prev => [
      ...prev,
      { id: Date.now(), name: newTag.trim(), color: "#5B21B6" }
    ]);
    setNewTag("");
  };

  const handleDelete = id => {
    setCategories(prev => prev.filter(c => c.id !== id));
  };

  const filtered = categories.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#1E3A8A] text-white font-inter flex flex-col">
      {/* Header */}
      <header className="bg-[#1E3A8A] py-4 shadow-md">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          <h1 className="text-3xl font-semibold">Categories</h1>
          <nav className="space-x-4">
            <a href="/" className="hover:underline">Home</a>
            <a href="/categories" className="hover:underline">Categories</a>
            <a href="/settings" className="hover:underline">Settings</a>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 gap-6">
          {/* Search & Add */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0 bg-[#1E3A8A] rounded-lg p-6 shadow-md">
            <input
              type="text"
              placeholder="Search categories..."
              className="w-full sm:w-1/2 bg-[#071C4E] text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            <div className="flex space-x-2 w-full sm:w-auto">
              <input
                type="text"
                placeholder="New category name"
                className="flex-1 bg-[#071C4E] text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={newTag}
                onChange={e => setNewTag(e.target.value)}
              />
              <button
                onClick={handleAdd}
                className="bg-[#2563EB] hover:bg-[#1E40AF] text-white font-medium rounded-lg px-6 py-2 transition-colors duration-200"
              >
                Add
              </button>
            </div>
          </div>

          {/* Category List */}
          <div className="overflow-x-auto bg-[#071C4E] rounded-lg shadow-md">
            <table className="min-w-full divide-y divide-[#374151]">
              <thead className="bg-[#1E3A8A]">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-white uppercase tracking-wider">
                    Color
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-white uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-[#1E3A8A] divide-y divide-[#374151]">
                {filtered.map(cat => (
                  <tr key={cat.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{cat.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">{cat.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className="inline-block w-6 h-6 rounded-full"
                        style={{ backgroundColor: cat.color }}
                      ></span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm flex justify-center space-x-2">
                      <button
                        className="text-[#F59E0B] hover:text-[#DF8A00] transition-colors duration-200"
                        title="Edit"
                      >
                        ✏️
                      </button>
                      <button
                        onClick={() => handleDelete(cat.id)}
                        className="text-[#EF4444] hover:text-[#CC212